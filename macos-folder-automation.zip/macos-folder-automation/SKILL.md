---
name: macos-folder-automation
description: Create macOS folder watchers using launchd + AppleScript. This skill should be used when the user wants to automatically process files when they appear in a folder (screenshots, downloads, voice memos, etc.). Handles macOS security restrictions by using AppleScript/Finder to list files instead of find command.
---

# macOS Folder Automation

Create folder watchers that automatically trigger scripts when files change, using native macOS launchd and AppleScript.

## Architecture

The automation system has three components:

1. **launchd plist** - Watches a folder for changes, triggers the script
2. **Watch script** - Lists files using AppleScript (bypasses macOS security), processes new ones
3. **Processing logic** - Does the actual work (rename, convert, transcribe, etc.)

## Key Insight: AppleScript for File Listing

macOS security blocks `find` and `ls` from accessing protected folders (Desktop, Downloads, Documents) when run from launchd. **Use AppleScript/Finder instead** - it has different permission handling.

## Creating a New Automation

### Step 1: Create the launchd plist

Location: `~/Library/LaunchAgents/com.automation.<name>.plist`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.automation.<name></string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/<username>/.automation/scripts/watch-<name>.sh</string>
    </array>
    <key>WatchPaths</key>
    <array>
        <string>/path/to/watch</string>
    </array>
    <key>StandardOutPath</key>
    <string>/tmp/launchd-<name>.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/launchd-<name>.log</string>
</dict>
</plist>
```

### Step 2: Create the watch script

Location: `~/.automation/scripts/watch-<name>.sh`

```bash
#!/bin/bash
LOG="/tmp/launchd-<name>.log"
PROCESSED_FILE="/tmp/processed-<name>.txt"
touch "$PROCESSED_FILE"

echo "$(date): Folder changed" >> "$LOG"

# Use AppleScript to list files (bypasses macOS security)
files=$(osascript -e '
tell application "Finder"
    set targetFolder to folder "<folder-name>" of home
    set matchingFiles to every file of targetFolder whose name ends with ".<ext>"
    set output to ""
    repeat with f in matchingFiles
        set filePath to POSIX path of (f as alias)
        set output to output & filePath & "\n"
    end repeat
    return output
end tell
' 2>/dev/null)

if [ -z "$files" ]; then
    exit 0
fi

echo -e "$files" | while read -r file; do
    [ -z "$file" ] && continue
    [ ! -f "$file" ] && continue

    # Check if modified recently (e.g., last 5 minutes)
    mtime=$(stat -f %m "$file" 2>/dev/null)
    now=$(date +%s)
    age=$(( (now - mtime) / 60 ))
    if [ "$age" -ge 5 ]; then
        continue
    fi

    # Skip if already processed
    file_id=$(echo "$file" | md5 -q)
    if grep -q "$file_id" "$PROCESSED_FILE" 2>/dev/null; then
        continue
    fi

    echo "$(date): Processing: $file" >> "$LOG"
    echo "$file_id" >> "$PROCESSED_FILE"

    # === YOUR PROCESSING LOGIC HERE ===

done

# Cleanup old entries
tail -100 "$PROCESSED_FILE" > "$PROCESSED_FILE.tmp" 2>/dev/null && mv "$PROCESSED_FILE.tmp" "$PROCESSED_FILE"
```

### Step 3: Load the automation

```bash
chmod +x ~/.automation/scripts/watch-<name>.sh
launchctl load ~/Library/LaunchAgents/com.automation.<name>.plist
```

## Common AppleScript Patterns

### List files by extension
```applescript
every file of targetFolder whose name ends with ".png"
```

### List files by prefix
```applescript
every file of targetFolder whose name starts with "Screenshot"
```

### Multiple conditions
```applescript
every file of targetFolder whose name starts with "Screenshot" and name ends with ".png"
```

### Specific folders
```applescript
folder "Desktop" of home
folder "Downloads" of home
folder "Documents" of home
(POSIX file "/path/to/folder") as alias
```

## Management Commands

```bash
# List loaded automations
launchctl list | grep automation

# Unload (stop) an automation
launchctl unload ~/Library/LaunchAgents/com.automation.<name>.plist

# Reload after changes
launchctl unload ~/Library/LaunchAgents/com.automation.<name>.plist
launchctl load ~/Library/LaunchAgents/com.automation.<name>.plist

# Check logs
tail -f /tmp/launchd-<name>.log

# Clear processed files to reprocess
rm /tmp/processed-<name>.txt
```

## Troubleshooting

### "Operation not permitted" errors
Use AppleScript/Finder instead of `find` or `ls` for protected folders.

### Script not triggering
1. Check launchctl list shows the agent
2. Check the WatchPaths in the plist is correct
3. Try modifying a file in the watched folder to trigger

### Files not found
Ensure AppleScript folder reference is correct. Test the osascript command manually first.

## Resources

See `references/examples.md` for complete working examples:
- Screenshot renaming with Claude
- HEIC to JPG conversion
- Voice memo transcription
