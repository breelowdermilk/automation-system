# Complete Automation Examples

## Screenshot Renaming with Claude

Watches Desktop for new screenshots, renames them with AI-generated descriptive names.

### Plist: `~/Library/LaunchAgents/com.automation.screenshots.plist`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.automation.screenshots</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/breelowdermilk/.automation/scripts/watch-screenshots.sh</string>
    </array>
    <key>WatchPaths</key>
    <array>
        <string>/Users/breelowdermilk/Desktop</string>
    </array>
    <key>StandardOutPath</key>
    <string>/tmp/launchd-screenshots.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/launchd-screenshots.log</string>
</dict>
</plist>
```

### Script: `~/.automation/scripts/watch-screenshots.sh`

```bash
#!/bin/bash
LOG="/tmp/launchd-screenshots.log"
PROCESSED_FILE="/tmp/processed-screenshots.txt"
touch "$PROCESSED_FILE"

echo "$(date): Desktop changed" >> "$LOG"

export PATH="/Users/breelowdermilk/.npm-global/bin:/Library/Frameworks/Python.framework/Versions/3.12/bin:$PATH"

# Use AppleScript to list files
files=$(osascript -e '
tell application "Finder"
    set desktopPath to path to desktop folder
    set screenshots to every file of desktopPath whose name starts with "Screenshot" and name ends with ".png"
    set output to ""
    repeat with f in screenshots
        set filePath to POSIX path of (f as alias)
        set output to output & filePath & "\n"
    end repeat
    return output
end tell
' 2>/dev/null)

if [ -z "$files" ]; then
    exit 0
fi

echo -e "$files" | while read -r file; do
    [ -z "$file" ] && continue
    [ ! -f "$file" ] && continue

    mtime=$(stat -f %m "$file" 2>/dev/null)
    now=$(date +%s)
    age=$(( (now - mtime) / 60 ))
    if [ "$age" -ge 5 ]; then
        continue
    fi

    file_id=$(echo "$file" | md5 -q)
    if grep -q "$file_id" "$PROCESSED_FILE" 2>/dev/null; then
        continue
    fi

    echo "$(date): Processing: $file" >> "$LOG"
    echo "$file_id" >> "$PROCESSED_FILE"

    # Call Claude to rename
    CLAUDE_MODEL=sonnet /path/to/claude-image-renamer.sh "$file" >> "$LOG" 2>&1

    echo "$(date): Done" >> "$LOG"
done

tail -100 "$PROCESSED_FILE" > "$PROCESSED_FILE.tmp" 2>/dev/null && mv "$PROCESSED_FILE.tmp" "$PROCESSED_FILE"
```

---

## HEIC to JPG Conversion

Watches Downloads for HEIC files, converts to JPG on Desktop.

### Plist: `~/Library/LaunchAgents/com.automation.downloads.plist`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.automation.downloads</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/breelowdermilk/.automation/scripts/watch-downloads.sh</string>
    </array>
    <key>WatchPaths</key>
    <array>
        <string>/Users/breelowdermilk/Downloads</string>
    </array>
    <key>StandardOutPath</key>
    <string>/tmp/launchd-downloads.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/launchd-downloads.log</string>
</dict>
</plist>
```

### Script: `~/.automation/scripts/watch-downloads.sh`

```bash
#!/bin/bash
LOG="/tmp/launchd-downloads.log"
PROCESSED_FILE="/tmp/processed-downloads.txt"
touch "$PROCESSED_FILE"

echo "$(date): Downloads changed" >> "$LOG"

files=$(osascript -e '
tell application "Finder"
    set dlFolder to folder "Downloads" of home
    set heicFiles to every file of dlFolder whose name ends with ".HEIC" or name ends with ".heic"
    set output to ""
    repeat with f in heicFiles
        set filePath to POSIX path of (f as alias)
        set output to output & filePath & "\n"
    end repeat
    return output
end tell
' 2>/dev/null)

if [ -z "$files" ]; then
    exit 0
fi

echo -e "$files" | while read -r file; do
    [ -z "$file" ] && continue
    [ ! -f "$file" ] && continue

    mtime=$(stat -f %m "$file" 2>/dev/null)
    now=$(date +%s)
    age=$(( (now - mtime) / 60 ))
    if [ "$age" -ge 10 ]; then
        continue
    fi

    file_id=$(echo "$file" | md5 -q)
    if grep -q "$file_id" "$PROCESSED_FILE" 2>/dev/null; then
        continue
    fi

    echo "$(date): Converting: $file" >> "$LOG"
    echo "$file_id" >> "$PROCESSED_FILE"

    basename=$(basename "$file")
    name="${basename%.*}"
    output_file="$HOME/Desktop/${name}.jpg"

    sips -s format jpeg "$file" --out "$output_file" >> "$LOG" 2>&1
    echo "$(date): Created $output_file" >> "$LOG"
done

tail -100 "$PROCESSED_FILE" > "$PROCESSED_FILE.tmp" 2>/dev/null && mv "$PROCESSED_FILE.tmp" "$PROCESSED_FILE"
```

---

## Voice Memo Transcription

Watches Voice Memos folder, transcribes with Whisper, categorizes with Claude, creates Obsidian note.

### Plist: `~/Library/LaunchAgents/com.automation.voicememos.plist`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.automation.voicememos</string>
    <key>ProgramArguments</key>
    <array>
        <string>/Users/breelowdermilk/.automation/scripts/watch-voicememos.sh</string>
    </array>
    <key>WatchPaths</key>
    <array>
        <string>/Users/breelowdermilk/Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings</string>
    </array>
    <key>StandardOutPath</key>
    <string>/tmp/launchd-voicememos.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/launchd-voicememos.log</string>
</dict>
</plist>
```

### Script: `~/.automation/scripts/watch-voicememos.sh`

```bash
#!/bin/bash
LOG="/tmp/launchd-voicememos.log"
PROCESSED_FILE="/tmp/processed-voicememos.txt"
OBSIDIAN_VAULT="$HOME/Writing"
touch "$PROCESSED_FILE"

echo "$(date): Voice Memos changed" >> "$LOG"

export PATH="/Users/breelowdermilk/.npm-global/bin:/opt/homebrew/bin:$PATH"

RECORDINGS_DIR="$HOME/Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings"
files=$(find "$RECORDINGS_DIR" -maxdepth 1 -name "*.m4a" -mmin -30 2>/dev/null)

if [ -z "$files" ]; then
    exit 0
fi

echo "$files" | while read -r file; do
    [ -z "$file" ] && continue

    file_id=$(echo "$file" | md5 -q)
    if grep -q "$file_id" "$PROCESSED_FILE" 2>/dev/null; then
        continue
    fi

    echo "$(date): Processing: $file" >> "$LOG"
    echo "$file_id" >> "$PROCESSED_FILE"

    # Transcribe with Whisper
    whisper "$file" --model base.en --output_format txt --output_dir /tmp >> "$LOG" 2>&1
    transcript=$(cat "/tmp/$(basename "$file" .m4a).txt" 2>/dev/null)

    # Categorize with Claude
    categorization=$(claude --model haiku --print -p "Categorize this transcript as JSON with title, project, summary: $transcript" 2>/dev/null)

    # Create Obsidian note
    date_str=$(date +%Y-%m-%d)
    note_path="$OBSIDIAN_VAULT/voice-memos/${date_str}-memo.md"
    mkdir -p "$OBSIDIAN_VAULT/voice-memos"

    cat > "$note_path" << EOF
---
date: $(date -Iseconds)
type: voice-memo
---

# Voice Memo

$transcript
EOF

    echo "$(date): Created $note_path" >> "$LOG"
done

tail -100 "$PROCESSED_FILE" > "$PROCESSED_FILE.tmp" 2>/dev/null && mv "$PROCESSED_FILE.tmp" "$PROCESSED_FILE"
```
